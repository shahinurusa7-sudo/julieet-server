const mongoose = require('mongoose');

const pendingMessageSchema = new mongoose.Schema({
  // Message identification
  messageId: {
    type: String,
    required: true,
    unique: true,
    index: true
  },

  // Sender and receiver information
  senderId: {
    type: String,
    required: true,
    index: true
  },
  receiverId: {
    type: String,
    required: true,
    index: true
  },

  // Chat information
  chatId: {
    type: String,
    required: true,
    index: true
  },

  // Message content
  messageType: {
    type: String,
    enum: ['text', 'image', 'video', 'audio', 'file', 'location'],
    default: 'text'
  },
  content: {
    type: String,
    required: true
  },
  mediaUrl: {
    type: String,
    default: null
  },
  thumbnailUrl: {
    type: String,
    default: null
  },

  // Delivery status
  status: {
    type: String,
    enum: ['pending', 'delivered', 'failed'],
    default: 'pending',
    index: true
  },

  // Retry mechanism
  retryCount: {
    type: Number,
    default: 0
  },
  maxRetries: {
    type: Number,
    default: 5
  },
  lastRetryAt: {
    type: Date,
    default: null
  },

  // Timestamps
  createdAt: {
    type: Date,
    default: Date.now,
    index: true
  },
  deliveredAt: {
    type: Date,
    default: null
  },
  expiresAt: {
    type: Date,
    default: () => new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
  },

  // Additional metadata
  metadata: {
    type: mongoose.Schema.Types.Mixed,
    default: {}
  }
}, {
  collection: 'temporary_sms_queue'
});

// Compound index for efficient queries
pendingMessageSchema.index({ receiverId: 1, status: 1, createdAt: 1 });
pendingMessageSchema.index({ chatId: 1, status: 1 });

// Auto-delete expired messages
pendingMessageSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

// Instance methods
pendingMessageSchema.methods.markAsDelivered = function () {
  this.status = 'delivered';
  this.deliveredAt = new Date();
  return this.save();
};

pendingMessageSchema.methods.markAsFailed = function () {
  this.status = 'failed';
  return this.save();
};

pendingMessageSchema.methods.incrementRetry = function () {
  this.retryCount += 1;
  this.lastRetryAt = new Date();
  return this.save();
};

// Static methods
pendingMessageSchema.statics.getPendingMessagesForUser = function (userId) {
  return this.find({
    receiverId: userId,
    status: 'pending'
  }).sort({ createdAt: 1 });
};

pendingMessageSchema.statics.getPendingMessagesByChat = function (chatId) {
  return this.find({
    chatId: chatId,
    status: 'pending'
  }).sort({ createdAt: 1 });
};

pendingMessageSchema.statics.cleanupOldMessages = function (daysOld = 7) {
  const cutoffDate = new Date(Date.now() - daysOld * 24 * 60 * 60 * 1000);
  return this.deleteMany({
    $or: [
      { status: 'delivered', deliveredAt: { $lt: cutoffDate } },
      { status: 'failed', createdAt: { $lt: cutoffDate } }
    ]
  });
};

const PendingMessage = mongoose.model('PendingMessage', pendingMessageSchema);

module.exports = PendingMessage;
